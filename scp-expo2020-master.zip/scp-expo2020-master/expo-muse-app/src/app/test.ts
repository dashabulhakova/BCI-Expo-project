export class test {
    hi: string;
}